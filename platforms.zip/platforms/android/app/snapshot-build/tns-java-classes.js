require("ui/frame/activity");
require("ui/frame/fragment");