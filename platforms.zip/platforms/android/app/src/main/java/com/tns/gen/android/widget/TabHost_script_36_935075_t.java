package com.tns.gen.android.widget;

public class TabHost_script_36_935075_t extends android.widget.TabHost implements com.tns.NativeScriptHashCodeProvider {
	public TabHost_script_36_935075_t(android.content.Context param_0){
		super(param_0);
		com.tns.Runtime.initInstance(this);
	}

	public TabHost_script_36_935075_t(android.content.Context param_0, android.util.AttributeSet param_1){
		super(param_0, param_1);
		com.tns.Runtime.initInstance(this);
	}

	public TabHost_script_36_935075_t(android.content.Context param_0, android.util.AttributeSet param_1, int param_2){
		super(param_0, param_1, param_2);
		com.tns.Runtime.initInstance(this);
	}

	public TabHost_script_36_935075_t(android.content.Context param_0, android.util.AttributeSet param_1, int param_2, int param_3){
		super(param_0, param_1, param_2, param_3);
		com.tns.Runtime.initInstance(this);
	}

	protected void onAttachedToWindow()  {
		java.lang.Object[] args = null;
		com.tns.Runtime.callJSMethod(this, "onAttachedToWindow", void.class, args);
	}

	public boolean equals__super(java.lang.Object other) {
		return super.equals(other);
	}

	public int hashCode__super() {
		return super.hashCode();
	}

}
