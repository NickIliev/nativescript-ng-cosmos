package com.tns.internal;

public interface Plugin {
    boolean execute(android.content.Context context) throws Exception;
}
